
/* 
 * File:   main.cpp
 * Author: Jason Handen
 * Created on May 16, 2021, 1:20 PM
 * Purpose: Time off program main
 */

#include <iostream>
#include <iomanip>
#include "numDays.h"
#include "timeOff.h"

using namespace std;

int main(int argc, char** argv) {
    
    //no driver program to be included in this question
    
    return 0;
}