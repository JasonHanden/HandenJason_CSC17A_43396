
/* 
 * File:   main.cpp
 * Author: Jason Handen
 * Created on May 15, 2021, 5:08 PM
 * Purpose: 
 */

#include <iostream>

#include "retailItem.h"

using namespace std;

int main(int argc, char** argv) {

    RetailItem item1("Jacket",12,59.95);
    RetailItem item2("Designer Jeans",40,34.95);
    RetailItem item3("Shirt",20,24.95);
    
    return 0;
}