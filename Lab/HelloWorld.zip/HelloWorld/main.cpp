
/* 
 * File:   main.cpp
 * Author: Jason Handen
 * Created on February 21, 2021, 2:04 PM
 * Purpose: print HelloWorld 
 */

#include <iostream>
using namespace std;

int main() {
    cout<< "Hello World!";
    return 0;
}