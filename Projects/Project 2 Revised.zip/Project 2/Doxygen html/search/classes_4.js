var searchData=
[
  ['result_14',['Result',['../class_result.html',1,'']]],
  ['round_15',['Round',['../class_round.html',1,'']]]
];
