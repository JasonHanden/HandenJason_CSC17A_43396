var indexSectionsWithContent =
{
  0: "abhpr",
  1: "abhpr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes"
};

