var searchData=
[
  ['badroundcount_1',['BadRoundCount',['../class_result_1_1_bad_round_count.html',1,'Result']]],
  ['badvalueex_2',['BadValueEx',['../class_result_1_1_bad_value_ex.html',1,'Result::BadValueEx'],['../class_round_1_1_bad_value_ex.html',1,'Round::BadValueEx']]],
  ['banker_3',['Banker',['../class_banker.html',1,'']]]
];
