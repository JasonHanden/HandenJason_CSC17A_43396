var searchData=
[
  ['result_6',['Result',['../class_result.html',1,'']]],
  ['round_7',['Round',['../class_round.html',1,'']]]
];
