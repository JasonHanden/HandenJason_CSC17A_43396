/* 
 * File:   Banker.cpp
 * Author: Jason Handen
 * Created on May 30, 2021, 8:40 PM
 * Purpose: Banker source file
 */

#include "Banker.h"

void Banker::drawThird(){
    // will implement this in a later revision
}